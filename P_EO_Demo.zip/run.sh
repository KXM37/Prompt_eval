#!/bin/bash
# Launch the Prompt Optimizer Demo

echo "🎯 Starting Prompt Optimization System..."
echo ""
echo "📋 To run with your API key:"
echo "   1. Open the app in your browser"
echo "   2. Enter your Anthropic API key in the sidebar"
echo "   3. Uncheck 'Demo Mode'"
echo ""
echo "🌐 The app will open in your default browser..."
echo ""

streamlit run app.py --server.headless true

# 🎯 Prompt Optimization System - Streamlit Demo

A scientific approach to prompt engineering with iterative improvement across 37 metrics.

## Features

- **📝 Input Section**: Enter or select sample prompts for optimization
- **🔄 Iteration Log**: Real-time scrollable progress during optimization
- **📊 Results Dashboard**: Comprehensive scoring breakdown with detailed metrics
- **🔐 Sidebar Authentication**: API key input for LLM evaluation mode

## Architecture

### Three Main Sections

1. **Input Section** (Left Column)
   - Text area for prompt input
   - Sample prompt selector
   - Optimize and Clear buttons

2. **Iteration Log** (Right Column)
   - Scrollable container showing real-time progress
   - Color-coded status messages
   - Iteration-by-iteration updates

3. **Results Section** (Bottom)
   - Score metrics (Initial, Best, Achievement, Iterations)
   - Tabbed views:
     - Score Breakdown by category
     - Best Optimized Prompt
     - Detailed Metrics with evidence
     - Iteration History

### Sidebar

- API Key authentication (password field)
- Demo mode toggle
- Configurable settings (max iterations, target score)
- Scoring information

## Metrics System

**150 Total Points** across **37 Metrics** in **7 Categories**:

| Category | Points | Metrics |
|----------|--------|---------|
| Structure & Clarity | 25 | 5 |
| Context & Information | 25 | 5 |
| Reasoning & Cognition | 30 | 6 |
| Safety & Alignment | 30 | 6 |
| Format & Style | 15 | 5 |
| Output Quality | 20 | 6 |
| Advanced Features | 5 | 3 |

### Evaluation Types

- **Custom Functions (10 metrics)**: Pattern-based regex detection
- **LLM Judge (27 metrics)**: Claude API-based assessment

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Demo Mode (No API Key)
```bash
streamlit run app.py
```

### Full Mode (With API Key)
1. Run the app: `streamlit run app.py`
2. Enter your Anthropic API key in the sidebar
3. Uncheck "Demo Mode"
4. Enter or select a prompt
5. Click "Optimize Prompt"

## Configuration

Adjustable via sidebar:
- **Max Iterations**: 1-10 (default: 5)
- **Target Score**: 60-150 (default: 120)

## How It Works

1. **Evaluation**: Prompt is scored against all 37 metrics
2. **Analysis**: Below-threshold metrics are identified
3. **Improvement**: LLM generates enhanced prompt targeting weak areas
4. **Iteration**: Process repeats until target reached or max iterations hit
5. **Best Tracking**: Highest-scoring prompt is always preserved

## Output

- Real-time progress logs
- Score breakdown by category
- Optimized prompt ready to copy
- Full iteration history
- Detailed metric evidence

"""
Prompt Optimization Demo - Streamlit Frontend
A scientific approach to prompt engineering with iterative improvement.
"""

import streamlit as st
import time
import json
import re
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import anthropic


# ============================================================================
# CONFIGURATION
# ============================================================================

METRIC_CONFIG = {
    # Structure & Clarity (25 points)
    "Clarity & Specificity": {
        "index": 1, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "structure_clarity",
        "description": "Is the prompt clear and specific about what's needed?"
    },
    "Explicit Task Definition": {
        "index": 3, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "structure_clarity",
        "description": "Is the task explicitly defined?"
    },
    "Avoiding Ambiguity or Contradictions": {
        "index": 5, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "structure_clarity",
        "description": "Does the prompt avoid ambiguity and contradictions?"
    },
    "Structured / Numbered Instructions": {
        "index": 10, "type": "custom_function", "max_points": 5.0, "threshold": 3.5,
        "group": "structure_clarity",
        "description": "Does the prompt use structured or numbered instructions?"
    },
    "Brevity vs. Detail Balance": {
        "index": 11, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "structure_clarity",
        "description": "Is there a good balance between brevity and detail?"
    },
    
    # Context & Information (25 points)
    "Context / Background Provided": {
        "index": 2, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "context_information",
        "description": "Is sufficient context or background provided?"
    },
    "Desired Output Format / Style": {
        "index": 7, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "context_information",
        "description": "Is the desired output format specified?"
    },
    "Examples or Demonstrations": {
        "index": 13, "type": "custom_function", "max_points": 5.0, "threshold": 3.5,
        "group": "context_information",
        "description": "Does the prompt include examples?"
    },
    "Knowledge Boundary Awareness": {
        "index": 16, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "context_information",
        "description": "Does the prompt acknowledge knowledge boundaries?"
    },
    "Limitations Disclosure": {
        "index": 30, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "context_information",
        "description": "Does the prompt disclose expected limitations?"
    },
    
    # Reasoning & Cognition (30 points)
    "Step-by-Step Reasoning Encouraged": {
        "index": 9, "type": "custom_function", "max_points": 5.0, "threshold": 3.5,
        "group": "reasoning_cognition",
        "description": "Does the prompt encourage step-by-step reasoning?"
    },
    "Iteration / Refinement Potential": {
        "index": 12, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "reasoning_cognition",
        "description": "Does the prompt allow for iteration and refinement?"
    },
    "Meta-Cognition Triggers": {
        "index": 20, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "reasoning_cognition",
        "description": "Does the prompt trigger meta-cognitive processes?"
    },
    "Divergent vs. Convergent Thinking Management": {
        "index": 21, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "reasoning_cognition",
        "description": "Does the prompt manage thinking styles appropriately?"
    },
    "Hypothetical Frame Switching": {
        "index": 22, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "reasoning_cognition",
        "description": "Does the prompt enable hypothetical reasoning?"
    },
    "Progressive Complexity": {
        "index": 24, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "reasoning_cognition",
        "description": "Does the prompt handle progressive complexity?"
    },
    
    # Safety & Alignment (30 points)
    "Handling Uncertainty / Gaps": {
        "index": 14, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "safety_alignment",
        "description": "Does the prompt address uncertainty handling?"
    },
    "Hallucination Minimization": {
        "index": 15, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "safety_alignment",
        "description": "Does the prompt include hallucination safeguards?"
    },
    "Safe Failure Mode": {
        "index": 23, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "safety_alignment",
        "description": "Does the prompt define safe failure modes?"
    },
    "Alignment with Evaluation Metrics": {
        "index": 25, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "safety_alignment",
        "description": "Is the prompt aligned with evaluation criteria?"
    },
    "Ethical Alignment or Bias Mitigation": {
        "index": 29, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "safety_alignment",
        "description": "Does the prompt address ethical concerns?"
    },
    "Compression / Summarization Ability": {
        "index": 31, "type": "llm_judge", "max_points": 5.0, "threshold": 3.5,
        "group": "safety_alignment",
        "description": "Can the output be appropriately compressed?"
    },
    
    # Format & Style (15 points)
    "Use of Role or Persona": {
        "index": 8, "type": "custom_function", "max_points": 3.0, "threshold": 2.1,
        "group": "format_style",
        "description": "Does the prompt use role or persona assignment?"
    },
    "Audience Specification": {
        "index": 17, "type": "llm_judge", "max_points": 3.0, "threshold": 2.1,
        "group": "format_style",
        "description": "Is the target audience specified?"
    },
    "Style Emulation or Imitation": {
        "index": 18, "type": "llm_judge", "max_points": 3.0, "threshold": 2.1,
        "group": "format_style",
        "description": "Does the prompt request style emulation?"
    },
    "Emotional Resonance Calibration": {
        "index": 32, "type": "llm_judge", "max_points": 3.0, "threshold": 2.1,
        "group": "format_style",
        "description": "Does the prompt calibrate emotional tone?"
    },
    "Cross-Disciplinary Bridging": {
        "index": 33, "type": "llm_judge", "max_points": 3.0, "threshold": 2.1,
        "group": "format_style",
        "description": "Does the prompt bridge multiple disciplines?"
    },
    
    # Output Quality (20 points)
    "Feasibility within Model Constraints": {
        "index": 4, "type": "llm_judge", "max_points": 3.33, "threshold": 2.33,
        "group": "output_quality",
        "description": "Is the task feasible for the model?"
    },
    "Model Fit / Scenario Appropriateness": {
        "index": 6, "type": "llm_judge", "max_points": 3.33, "threshold": 2.33,
        "group": "output_quality",
        "description": "Is the task appropriate for an LLM?"
    },
    "Output Validation Hooks": {
        "index": 27, "type": "custom_function", "max_points": 3.33, "threshold": 2.33,
        "group": "output_quality",
        "description": "Does the prompt include validation requests?"
    },
    "Time/Effort Estimation Request": {
        "index": 28, "type": "custom_function", "max_points": 3.33, "threshold": 2.33,
        "group": "output_quality",
        "description": "Does the prompt request time/effort estimates?"
    },
    "Output Risk Categorization": {
        "index": 34, "type": "llm_judge", "max_points": 3.33, "threshold": 2.33,
        "group": "output_quality",
        "description": "Does the prompt categorize output risks?"
    },
    "Self-Repair Loops": {
        "index": 35, "type": "custom_function", "max_points": 3.33, "threshold": 2.33,
        "group": "output_quality",
        "description": "Does the prompt enable self-correction?"
    },
    
    # Advanced Features (5 points)
    "Memory Anchoring": {
        "index": 19, "type": "custom_function", "max_points": 1.67, "threshold": 1.17,
        "group": "advanced_features",
        "description": "Does the prompt anchor to previous context?"
    },
    "Calibration Requests": {
        "index": 26, "type": "custom_function", "max_points": 1.67, "threshold": 1.17,
        "group": "advanced_features",
        "description": "Does the prompt request calibration?"
    },
    "Comparison Requests": {
        "index": None, "type": "custom_function", "max_points": 1.66, "threshold": 1.16,
        "group": "advanced_features",
        "description": "Does the prompt request comparisons?"
    }
}

CONFIG = {
    "max_score": 150,
    "max_iterations": 5,
    "target_score": 120,
    "min_improvement": 3,
    "metric_threshold_pct": 0.70,
    "llm_batch_size": 5,
}

GROUP_INFO = {
    "structure_clarity": {"name": "Structure & Clarity", "max": 25, "emoji": "📐"},
    "context_information": {"name": "Context & Information", "max": 25, "emoji": "📚"},
    "reasoning_cognition": {"name": "Reasoning & Cognition", "max": 30, "emoji": "🧠"},
    "safety_alignment": {"name": "Safety & Alignment", "max": 30, "emoji": "🛡️"},
    "format_style": {"name": "Format & Style", "max": 15, "emoji": "🎨"},
    "output_quality": {"name": "Output Quality", "max": 20, "emoji": "✅"},
    "advanced_features": {"name": "Advanced Features", "max": 5, "emoji": "⚡"},
}


# ============================================================================
# CUSTOM METRIC EVALUATOR
# ============================================================================

class CustomMetricEvaluator:
    """Pattern-based metric evaluation using regex and keyword detection."""
    
    def __init__(self, metric_config: dict):
        self.metric_config = metric_config
    
    def evaluate_all(self, prompt: str) -> Dict[str, Dict]:
        """Evaluate all custom function metrics."""
        results = {}
        custom_metrics = {
            name: config for name, config in self.metric_config.items()
            if config['type'] == 'custom_function'
        }
        
        for metric_name, config in custom_metrics.items():
            score, evidence = self._evaluate_metric(metric_name, prompt, config)
            results[metric_name] = {
                'score': score,
                'max_points': config['max_points'],
                'threshold': config['threshold'],
                'below_threshold': score < config['threshold'],
                'evidence': evidence,
                'type': 'custom_function'
            }
        return results
    
    def _evaluate_metric(self, metric_name: str, prompt: str, config: dict) -> Tuple[float, str]:
        """Route to specific evaluation function."""
        evaluators = {
            "Structured / Numbered Instructions": self._eval_structured_instructions,
            "Examples or Demonstrations": self._eval_examples,
            "Step-by-Step Reasoning Encouraged": self._eval_step_by_step,
            "Use of Role or Persona": self._eval_role_persona,
            "Output Validation Hooks": self._eval_validation_hooks,
            "Time/Effort Estimation Request": self._eval_time_effort,
            "Self-Repair Loops": self._eval_self_repair,
            "Memory Anchoring": self._eval_memory_anchoring,
            "Calibration Requests": self._eval_calibration,
            "Comparison Requests": self._eval_comparison,
        }
        
        if metric_name in evaluators:
            return evaluators[metric_name](prompt, config['max_points'])
        return 0, "No evaluator found"
    
    def _eval_structured_instructions(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        numbered_pattern = r'(?:^|\n)\s*\d+[\.\)]\s+'
        numbered_matches = len(re.findall(numbered_pattern, prompt))
        if numbered_matches >= 3:
            score += max_points * 0.5
            evidence_parts.append(f"{numbered_matches} numbered items")
        elif numbered_matches > 0:
            score += max_points * 0.25
            evidence_parts.append(f"{numbered_matches} numbered item(s)")
        
        bullet_pattern = r'(?:^|\n)\s*[-•*]\s+'
        bullet_matches = len(re.findall(bullet_pattern, prompt))
        if bullet_matches >= 3:
            score += max_points * 0.3
            evidence_parts.append(f"{bullet_matches} bullet points")
        elif bullet_matches > 0:
            score += max_points * 0.15
            evidence_parts.append(f"{bullet_matches} bullet point(s)")
        
        section_keywords = ['step', 'phase', 'section', 'part', 'stage']
        section_count = sum(1 for kw in section_keywords if kw.lower() in prompt.lower())
        if section_count >= 2:
            score += max_points * 0.2
            evidence_parts.append(f"{section_count} section keywords")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No structure detected"
        return min(score, max_points), evidence
    
    def _eval_examples(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        example_keywords = [
            r'\bexample[s]?\b', r'\bfor instance\b', r'\bsuch as\b',
            r'\be\.g\.\b', r'\bdemonstrat', r'\bsample\b', r'\blike this\b'
        ]
        
        matches = []
        for pattern in example_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower() for m in matches))
        if unique_matches >= 3:
            score = max_points
            evidence_parts.append(f"{unique_matches} example indicators")
        elif unique_matches == 2:
            score = max_points * 0.7
            evidence_parts.append(f"{unique_matches} example indicators")
        elif unique_matches == 1:
            score = max_points * 0.4
            evidence_parts.append(f"{unique_matches} example indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No examples detected"
        return score, evidence
    
    def _eval_step_by_step(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        reasoning_keywords = [
            r'\bstep[- ]by[- ]step\b', r'\bthink through\b', r'\breason\b',
            r'\blet\'s think\b', r'\bfirst,?\s', r'\bthen,?\s', r'\bfinally,?\s',
            r'\bchain of thought\b', r'\bwork through\b', r'\bbreak down\b'
        ]
        
        matches = []
        for pattern in reasoning_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower().strip() for m in matches))
        if unique_matches >= 3:
            score = max_points
            evidence_parts.append(f"{unique_matches} reasoning indicators")
        elif unique_matches == 2:
            score = max_points * 0.7
            evidence_parts.append(f"{unique_matches} reasoning indicators")
        elif unique_matches == 1:
            score = max_points * 0.4
            evidence_parts.append(f"{unique_matches} reasoning indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No step-by-step reasoning detected"
        return score, evidence
    
    def _eval_role_persona(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        role_patterns = [
            r'\bact as\b', r'\byou are\b', r'\bas a[n]?\s+\w+', r'\brole of\b',
            r'\bpersona\b', r'\bexpert\b', r'\bspecialist\b', r'\bprofessional\b',
            r'\bconsultant\b', r'\badvisor\b', r'\banalyst\b'
        ]
        
        matches = []
        for pattern in role_patterns:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        if len(matches) >= 2:
            score = max_points
            evidence_parts.append(f"{len(matches)} role/persona indicators")
        elif len(matches) == 1:
            score = max_points * 0.6
            evidence_parts.append(f"{len(matches)} role/persona indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No role/persona detected"
        return score, evidence
    
    def _eval_validation_hooks(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        validation_keywords = [
            r'\bverify\b', r'\bvalidate\b', r'\bcheck\b', r'\bconfirm\b',
            r'\bensure\b', r'\breview\b', r'\bdouble[- ]check\b', r'\btest\b'
        ]
        
        matches = []
        for pattern in validation_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower() for m in matches))
        if unique_matches >= 2:
            score = max_points
            evidence_parts.append(f"{unique_matches} validation indicators")
        elif unique_matches == 1:
            score = max_points * 0.5
            evidence_parts.append(f"{unique_matches} validation indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No validation hooks detected"
        return score, evidence
    
    def _eval_time_effort(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        time_keywords = [
            r'\bestimate\b', r'\btime\b', r'\beffort\b', r'\bduration\b',
            r'\bhow long\b', r'\bcomplexity\b', r'\bdifficulty\b'
        ]
        
        matches = []
        for pattern in time_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower() for m in matches))
        if unique_matches >= 2:
            score = max_points
            evidence_parts.append(f"{unique_matches} time/effort indicators")
        elif unique_matches == 1:
            score = max_points * 0.5
            evidence_parts.append(f"{unique_matches} time/effort indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No time/effort requests detected"
        return score, evidence
    
    def _eval_self_repair(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        repair_keywords = [
            r'\biterate\b', r'\brefine\b', r'\bimprove\b', r'\brevise\b',
            r'\badjust\b', r'\boptimize\b', r'\benhance\b', r'\bself-correct\b',
            r'\bfeedback loop\b', r'\biterative\b'
        ]
        
        matches = []
        for pattern in repair_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower() for m in matches))
        if unique_matches >= 3:
            score = max_points
            evidence_parts.append(f"{unique_matches} self-repair indicators")
        elif unique_matches == 2:
            score = max_points * 0.7
            evidence_parts.append(f"{unique_matches} self-repair indicators")
        elif unique_matches == 1:
            score = max_points * 0.4
            evidence_parts.append(f"{unique_matches} self-repair indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No self-repair loops detected"
        return score, evidence
    
    def _eval_memory_anchoring(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        memory_keywords = [
            r'\bremember\b', r'\brecall\b', r'\bpreviously\b', r'\bcontext from\b',
            r'\bas we discussed\b', r'\bearlier conversation\b', r'\bfrom before\b',
            r'\bkeep in mind\b', r'\bdon\'t forget\b'
        ]
        
        matches = []
        for pattern in memory_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower() for m in matches))
        if unique_matches >= 2:
            score = max_points
            evidence_parts.append(f"{unique_matches} memory anchoring indicators")
        elif unique_matches == 1:
            score = max_points * 0.6
            evidence_parts.append(f"{unique_matches} memory anchoring indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No memory anchoring detected"
        return score, evidence
    
    def _eval_calibration(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        calibration_patterns = [
            r'\bcalibrate\b', r'\bconfidence level\b', r'\bcertainty\b',
            r'\buncertainty\b', r'\bhow confident\b', r'\btune\b'
        ]
        
        matches = []
        for pattern in calibration_patterns:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        if len(matches) >= 2:
            score = max_points
            evidence_parts.append(f"{len(matches)} calibration indicators")
        elif len(matches) == 1:
            score = max_points * 0.6
            evidence_parts.append(f"{len(matches)} calibration indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No calibration requests detected"
        return score, evidence
    
    def _eval_comparison(self, prompt: str, max_points: float) -> Tuple[float, str]:
        evidence_parts = []
        score = 0
        
        comparison_keywords = [
            r'\bcompare\b', r'\bcontrast\b', r'\bvs\b', r'\bversus\b',
            r'\bdifference[s]?\b', r'\bsimilar\b', r'\balternative[s]?\b',
            r'\btrade[- ]?off[s]?\b', r'\bpros and cons\b'
        ]
        
        matches = []
        for pattern in comparison_keywords:
            found = re.findall(pattern, prompt, re.IGNORECASE)
            matches.extend(found)
        
        unique_matches = len(set(m.lower() for m in matches))
        if unique_matches >= 2:
            score = max_points
            evidence_parts.append(f"{unique_matches} comparison indicators")
        elif unique_matches == 1:
            score = max_points * 0.6
            evidence_parts.append(f"{unique_matches} comparison indicator")
        
        evidence = "; ".join(evidence_parts) if evidence_parts else "No comparison requests detected"
        return score, evidence


# ============================================================================
# LLM JUDGE EVALUATOR
# ============================================================================

class LLMJudgeEvaluator:
    """LLM-based metric evaluation using Claude API."""
    
    def __init__(self, metric_config: dict, config: dict, api_key: str = None):
        self.metric_config = metric_config
        self.config = config
        self.api_key = api_key
        self.client = anthropic.Anthropic(api_key=api_key) if api_key else None
    
    def evaluate_batch(self, prompt: str, metrics: List[str]) -> Dict[str, Dict]:
        """Evaluate a batch of metrics."""
        if not self.client:
            return self._mock_evaluate(metrics)
        
        metrics_text = "\n".join([
            f"- {name}: {self.metric_config[name]['description']} (max: {self.metric_config[name]['max_points']} pts)"
            for name in metrics
        ])
        
        eval_prompt = f"""Evaluate the following prompt against these metrics. 
For each metric, provide a score (0 to max points) and brief justification.

PROMPT TO EVALUATE:
\"\"\"
{prompt}
\"\"\"

METRICS TO EVALUATE:
{metrics_text}

Respond in JSON format:
{{
    "metric_name": {{
        "score": <number>,
        "justification": "<brief reason>"
    }},
    ...
}}

Be strict but fair. Only give high scores for clear evidence."""

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=2000,
                messages=[{"role": "user", "content": eval_prompt}]
            )
            
            response_text = response.content[0].text
            json_match = re.search(r'\{[\s\S]*\}', response_text)
            if json_match:
                parsed = json.loads(json_match.group())
                
                results = {}
                for metric_name in metrics:
                    config = self.metric_config[metric_name]
                    if metric_name in parsed:
                        score = min(parsed[metric_name].get('score', 0), config['max_points'])
                        justification = parsed[metric_name].get('justification', 'No justification')
                    else:
                        score = config['max_points'] * 0.3
                        justification = "Metric not evaluated by LLM"
                    
                    results[metric_name] = {
                        'score': score,
                        'max_points': config['max_points'],
                        'threshold': config['threshold'],
                        'below_threshold': score < config['threshold'],
                        'evidence': justification,
                        'type': 'llm_judge'
                    }
                return results
        except Exception as e:
            st.warning(f"LLM evaluation error: {e}")
            return self._mock_evaluate(metrics)
    
    def _mock_evaluate(self, metrics: List[str]) -> Dict[str, Dict]:
        """Generate mock evaluations for demo mode."""
        import random
        results = {}
        for metric_name in metrics:
            config = self.metric_config[metric_name]
            score = random.uniform(config['max_points'] * 0.2, config['max_points'] * 0.8)
            results[metric_name] = {
                'score': score,
                'max_points': config['max_points'],
                'threshold': config['threshold'],
                'below_threshold': score < config['threshold'],
                'evidence': f"[Mock] Estimated score based on prompt analysis",
                'type': 'llm_judge'
            }
        return results
    
    def evaluate_all(self, prompt: str, below_threshold_only: bool = False,
                     below_threshold_metrics: List[str] = None) -> Dict[str, Dict]:
        """Evaluate all LLM judge metrics."""
        llm_metrics = [
            name for name, config in self.metric_config.items()
            if config['type'] == 'llm_judge'
        ]
        
        if below_threshold_only and below_threshold_metrics:
            llm_metrics = [m for m in llm_metrics if m in below_threshold_metrics]
        
        if not llm_metrics:
            return {}
        
        all_results = {}
        batch_size = self.config.get('llm_batch_size', 5)
        
        for i in range(0, len(llm_metrics), batch_size):
            batch = llm_metrics[i:i + batch_size]
            batch_results = self.evaluate_batch(prompt, batch)
            all_results.update(batch_results)
        
        return all_results


# ============================================================================
# PROMPT IMPROVER
# ============================================================================

class PromptImprover:
    """Generate improved prompts targeting weak metrics."""
    
    def __init__(self, metric_config: dict, api_key: str = None):
        self.metric_config = metric_config
        self.api_key = api_key
        self.client = anthropic.Anthropic(api_key=api_key) if api_key else None
    
    def improve(self, prompt: str, below_threshold_metrics: Dict[str, Dict]) -> Tuple[str, str]:
        """Generate improved prompt targeting weak areas."""
        if not self.client:
            return self._mock_improve(prompt, below_threshold_metrics)
        
        weak_areas = "\n".join([
            f"- {name}: {data.get('evidence', 'Needs improvement')} (score: {data['score']:.1f}/{data['max_points']:.1f})"
            for name, data in below_threshold_metrics.items()
        ])
        
        improve_prompt = f"""Improve this prompt to address the weak areas identified below.

ORIGINAL PROMPT:
\"\"\"
{prompt}
\"\"\"

WEAK AREAS TO ADDRESS:
{weak_areas}

GUIDELINES:
1. Preserve the original intent and core request
2. Add elements that specifically address each weak metric
3. Use clear structure with numbered sections
4. Include examples where appropriate
5. Add safety and validation elements
6. Keep improvements focused and relevant

Respond in this format:
IMPROVED_PROMPT:
[Your improved prompt here]

CHANGES_MADE:
[Brief summary of what you changed and why]"""

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=3000,
                messages=[{"role": "user", "content": improve_prompt}]
            )
            
            response_text = response.content[0].text
            
            improved_prompt = prompt
            changes = "Improvements applied"
            
            if "IMPROVED_PROMPT:" in response_text:
                parts = response_text.split("IMPROVED_PROMPT:")
                if len(parts) > 1:
                    prompt_section = parts[1]
                    if "CHANGES_MADE:" in prompt_section:
                        prompt_parts = prompt_section.split("CHANGES_MADE:")
                        improved_prompt = prompt_parts[0].strip()
                        changes = prompt_parts[1].strip() if len(prompt_parts) > 1 else changes
                    else:
                        improved_prompt = prompt_section.strip()
            
            return improved_prompt, changes
            
        except Exception as e:
            st.warning(f"Improvement error: {e}")
            return self._mock_improve(prompt, below_threshold_metrics)
    
    def _mock_improve(self, prompt: str, below_threshold_metrics: Dict[str, Dict]) -> Tuple[str, str]:
        """Generate mock improvement for demo mode."""
        improvements = []
        
        if "Structured / Numbered Instructions" in below_threshold_metrics:
            improvements.append("structured numbered sections")
        if "Examples or Demonstrations" in below_threshold_metrics:
            improvements.append("concrete examples")
        if "Step-by-Step Reasoning Encouraged" in below_threshold_metrics:
            improvements.append("step-by-step reasoning")
        if "Use of Role or Persona" in below_threshold_metrics:
            improvements.append("expert role assignment")
        
        improved = f"""**Enhanced Prompt:**

You are an expert analyst. Please approach this task systematically.

{prompt}

**Instructions:**
1. First, analyze the core requirements
2. Then, develop your approach step-by-step
3. Provide concrete examples where relevant
4. Finally, validate your conclusions

**Example approach:**
- Break down complex aspects
- Consider multiple perspectives
- Verify key assumptions

Please think through this carefully and explain your reasoning."""
        
        changes = f"Added: {', '.join(improvements) if improvements else 'general improvements'}"
        return improved, changes


# ============================================================================
# FULL OPTIMIZER PIPELINE
# ============================================================================

class PromptOptimizer:
    """Complete prompt optimization pipeline."""
    
    def __init__(self, metric_config: dict, config: dict, api_key: str = None):
        self.metric_config = metric_config
        self.config = config
        self.api_key = api_key
        self.custom_evaluator = CustomMetricEvaluator(metric_config)
        self.llm_evaluator = LLMJudgeEvaluator(metric_config, config, api_key)
        self.improver = PromptImprover(metric_config, api_key)
    
    def evaluate(self, prompt: str, first_run: bool = True,
                 below_threshold_metrics: List[str] = None) -> Dict:
        """Run full evaluation pipeline."""
        custom_results = self.custom_evaluator.evaluate_all(prompt)
        
        llm_results = self.llm_evaluator.evaluate_all(
            prompt,
            below_threshold_only=not first_run,
            below_threshold_metrics=below_threshold_metrics
        )
        
        all_results = {**custom_results, **llm_results}
        
        total_score = sum(r['score'] for r in all_results.values())
        max_possible = sum(r['max_points'] for r in all_results.values())
        
        below_threshold = {
            name: data for name, data in all_results.items()
            if data['below_threshold']
        }
        
        group_scores = {}
        for group_key, group_info in GROUP_INFO.items():
            group_metrics = {
                name: data for name, data in all_results.items()
                if self.metric_config[name]['group'] == group_key
            }
            if group_metrics:
                group_scores[group_key] = {
                    'score': sum(m['score'] for m in group_metrics.values()),
                    'max': group_info['max'],
                    'metrics': group_metrics
                }
        
        return {
            'prompt': prompt,
            'total_score': total_score,
            'max_score': max_possible,
            'percentage': (total_score / max_possible * 100) if max_possible > 0 else 0,
            'all_results': all_results,
            'below_threshold': below_threshold,
            'below_threshold_count': len(below_threshold),
            'group_scores': group_scores,
            'timestamp': datetime.now().isoformat()
        }
    
    def optimize(self, initial_prompt: str, progress_callback=None) -> Dict:
        """Run full optimization loop."""
        history = []
        best_result = None
        best_score = 0
        current_prompt = initial_prompt
        
        for iteration in range(1, self.config['max_iterations'] + 1):
            if progress_callback:
                progress_callback(f"🔄 Iteration {iteration}: Evaluating prompt...")
            
            first_run = iteration == 1
            below_threshold_list = list(best_result['below_threshold'].keys()) if best_result else None
            
            result = self.evaluate(current_prompt, first_run=first_run,
                                   below_threshold_metrics=below_threshold_list)
            result['iteration'] = iteration
            history.append(result)
            
            if result['total_score'] > best_score:
                best_score = result['total_score']
                best_result = result.copy()
            
            if progress_callback:
                progress_callback(
                    f"✅ Iteration {iteration}: Score = {result['total_score']:.1f}/{result['max_score']:.1f} "
                    f"({result['percentage']:.1f}%) | Below threshold: {result['below_threshold_count']}"
                )
            
            # Check stopping conditions
            if result['total_score'] >= self.config['target_score']:
                if progress_callback:
                    progress_callback(f"🎯 Target score reached!")
                break
            
            if result['below_threshold_count'] == 0:
                if progress_callback:
                    progress_callback(f"✨ All metrics above threshold!")
                break
            
            if iteration >= self.config['max_iterations']:
                if progress_callback:
                    progress_callback(f"⏱️ Maximum iterations reached")
                break
            
            # Generate improvement
            if progress_callback:
                progress_callback(f"🔧 Generating improved prompt...")
            
            improved_prompt, changes = self.improver.improve(
                current_prompt, result['below_threshold']
            )
            result['changes'] = changes
            current_prompt = improved_prompt
        
        return {
            'initial_prompt': initial_prompt,
            'best_prompt': best_result['prompt'],
            'best_score': best_score,
            'best_result': best_result,
            'history': history,
            'iterations_run': len(history),
            'improvement': best_score - history[0]['total_score'] if history else 0
        }


# ============================================================================
# STREAMLIT APP
# ============================================================================

def init_session_state():
    """Initialize session state variables."""
    if 'optimization_results' not in st.session_state:
        st.session_state.optimization_results = None
    if 'iteration_logs' not in st.session_state:
        st.session_state.iteration_logs = []
    if 'is_running' not in st.session_state:
        st.session_state.is_running = False


def render_sidebar():
    """Render the sidebar with authentication and settings."""
    with st.sidebar:
        st.markdown("## 🔐 Authentication")
        
        api_key = st.text_input(
            "Anthropic API Key",
            type="password",
            help="Enter your Anthropic API key for LLM evaluation. Leave empty for demo mode."
        )
        
        use_mock = st.checkbox(
            "Demo Mode (No API calls)",
            value=not bool(api_key),
            help="Use simulated evaluations for demonstration"
        )
        
        st.divider()
        
        st.markdown("## ⚙️ Settings")
        
        max_iterations = st.slider(
            "Max Iterations",
            min_value=1,
            max_value=10,
            value=CONFIG['max_iterations'],
            help="Maximum optimization iterations"
        )
        
        target_score = st.slider(
            "Target Score",
            min_value=60,
            max_value=150,
            value=CONFIG['target_score'],
            help="Stop when this score is reached"
        )
        
        st.divider()
        
        st.markdown("## 📊 Scoring Info")
        st.markdown(f"""
        - **Max Score:** 150 points
        - **37 Metrics** across 7 categories
        - **Target:** {target_score} ({target_score/150*100:.0f}%)
        """)
        
        with st.expander("View Metric Groups"):
            for group_key, info in GROUP_INFO.items():
                st.markdown(f"{info['emoji']} **{info['name']}**: {info['max']} pts")
        
        return api_key, use_mock, max_iterations, target_score


def render_input_section():
    """Render the prompt input section."""
    st.markdown("## 📝 Input Prompt")
    
    sample_prompts = {
        "Simple (Low Score)": "Write about AI",
        "Basic (Medium Score)": "Explain how machine learning works. Use examples.",
        "Detailed (Higher Score)": """You are an expert data scientist. Please explain the differences between supervised and unsupervised learning.

**Instructions:**
1. Define each approach clearly
2. Provide 2-3 concrete examples for each
3. Compare their use cases
4. Discuss limitations of each approach

Think step-by-step and verify your explanations are accurate. If uncertain about specific claims, acknowledge the uncertainty."""
    }
    
    selected_sample = st.selectbox(
        "Load sample prompt:",
        ["Custom"] + list(sample_prompts.keys())
    )
    
    initial_value = sample_prompts.get(selected_sample, "") if selected_sample != "Custom" else ""
    
    prompt_input = st.text_area(
        "Enter your prompt to optimize:",
        value=initial_value,
        height=200,
        placeholder="Enter your prompt here... The system will evaluate and iteratively improve it."
    )
    
    return prompt_input


def render_iteration_section():
    """Render the scrollable iteration log section."""
    st.markdown("## 🔄 Optimization Progress")
    
    log_container = st.container(height=300)
    
    with log_container:
        if st.session_state.iteration_logs:
            for log in st.session_state.iteration_logs:
                if log.startswith("🎯") or log.startswith("✨"):
                    st.success(log)
                elif log.startswith("⚠️") or log.startswith("⏱️"):
                    st.warning(log)
                elif log.startswith("✅"):
                    st.info(log)
                else:
                    st.text(log)
        else:
            st.info("👆 Enter a prompt and click 'Optimize' to start")
    
    return log_container


def render_results_section():
    """Render the output results section."""
    st.markdown("## 📊 Results")
    
    if not st.session_state.optimization_results:
        st.info("Results will appear here after optimization")
        return
    
    results = st.session_state.optimization_results
    
    # Score summary
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        initial_score = results['history'][0]['total_score'] if results['history'] else 0
        st.metric(
            "Initial Score",
            f"{initial_score:.1f}/150",
            delta=None
        )
    
    with col2:
        st.metric(
            "Best Score",
            f"{results['best_score']:.1f}/150",
            delta=f"+{results['improvement']:.1f}"
        )
    
    with col3:
        pct = results['best_score'] / 150 * 100
        st.metric(
            "Achievement",
            f"{pct:.1f}%",
            delta=None
        )
    
    with col4:
        st.metric(
            "Iterations",
            results['iterations_run'],
            delta=None
        )
    
    st.divider()
    
    # Tabs for different views
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Score Breakdown", "📝 Best Prompt", "🔍 Detailed Metrics", "📜 History"])
    
    with tab1:
        render_score_breakdown(results)
    
    with tab2:
        render_best_prompt(results)
    
    with tab3:
        render_detailed_metrics(results)
    
    with tab4:
        render_history(results)


def render_score_breakdown(results: Dict):
    """Render score breakdown by category."""
    if not results['best_result']:
        return
    
    group_scores = results['best_result'].get('group_scores', {})
    
    st.markdown("### Score by Category")
    
    for group_key, info in GROUP_INFO.items():
        if group_key in group_scores:
            data = group_scores[group_key]
            score = data['score']
            max_score = data['max']
            pct = score / max_score * 100 if max_score > 0 else 0
            
            col1, col2 = st.columns([3, 1])
            with col1:
                st.progress(pct / 100, text=f"{info['emoji']} {info['name']}")
            with col2:
                st.write(f"{score:.1f}/{max_score}")


def render_best_prompt(results: Dict):
    """Render the best optimized prompt."""
    st.markdown("### Optimized Prompt")
    
    st.text_area(
        "Copy this optimized prompt:",
        value=results['best_prompt'],
        height=300,
        key="best_prompt_output"
    )
    
    if st.button("📋 Copy to Clipboard", key="copy_btn"):
        st.success("Prompt ready to copy from the text area above!")


def render_detailed_metrics(results: Dict):
    """Render detailed metric results."""
    if not results['best_result']:
        return
    
    st.markdown("### All Metrics")
    
    all_results = results['best_result'].get('all_results', {})
    
    # Group by category
    for group_key, info in GROUP_INFO.items():
        with st.expander(f"{info['emoji']} {info['name']}"):
            group_metrics = {
                name: data for name, data in all_results.items()
                if METRIC_CONFIG[name]['group'] == group_key
            }
            
            for metric_name, data in group_metrics.items():
                status = "✅" if not data['below_threshold'] else "⚠️"
                score = data['score']
                max_pts = data['max_points']
                
                col1, col2, col3 = st.columns([2, 1, 3])
                with col1:
                    st.write(f"{status} {metric_name}")
                with col2:
                    st.write(f"{score:.1f}/{max_pts:.1f}")
                with col3:
                    st.caption(data.get('evidence', '')[:50])


def render_history(results: Dict):
    """Render iteration history."""
    st.markdown("### Iteration History")
    
    history = results.get('history', [])
    
    for entry in history:
        iteration = entry.get('iteration', 0)
        score = entry.get('total_score', 0)
        below = entry.get('below_threshold_count', 0)
        changes = entry.get('changes', '')
        
        with st.expander(f"Iteration {iteration}: {score:.1f}/150"):
            st.write(f"**Score:** {score:.1f}/150 ({entry.get('percentage', 0):.1f}%)")
            st.write(f"**Metrics below threshold:** {below}")
            if changes:
                st.write(f"**Changes made:** {changes}")
            
            st.text_area(
                "Prompt at this iteration:",
                value=entry.get('prompt', ''),
                height=150,
                key=f"history_prompt_{iteration}"
            )


def add_log(message: str):
    """Add message to iteration logs."""
    st.session_state.iteration_logs.append(message)


def main():
    """Main Streamlit application."""
    st.set_page_config(
        page_title="Prompt Optimizer",
        page_icon="🎯",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Custom CSS
    st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .subtitle {
        color: #666;
        font-size: 1.1rem;
        margin-bottom: 2rem;
    }
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Header
    st.markdown('<h1 class="main-header">🎯 Prompt Optimization System</h1>', unsafe_allow_html=True)
    st.markdown('<p class="subtitle">Scientific prompt engineering with iterative improvement across 37 metrics</p>', unsafe_allow_html=True)
    
    # Initialize state
    init_session_state()
    
    # Sidebar
    api_key, use_mock, max_iterations, target_score = render_sidebar()
    
    # Main content
    col1, col2 = st.columns([1, 1])
    
    with col1:
        prompt_input = render_input_section()
        
        optimize_btn = st.button(
            "🚀 Optimize Prompt",
            type="primary",
            use_container_width=True,
            disabled=st.session_state.is_running or not prompt_input.strip()
        )
        
        if st.button("🗑️ Clear Results", use_container_width=True):
            st.session_state.optimization_results = None
            st.session_state.iteration_logs = []
            st.rerun()
    
    with col2:
        render_iteration_section()
    
    # Run optimization
    if optimize_btn and prompt_input.strip():
        st.session_state.is_running = True
        st.session_state.iteration_logs = []
        st.session_state.optimization_results = None
        
        # Update config
        CONFIG['max_iterations'] = max_iterations
        CONFIG['target_score'] = target_score
        
        # Initialize optimizer
        effective_api_key = api_key if not use_mock and api_key else None
        optimizer = PromptOptimizer(METRIC_CONFIG, CONFIG, api_key=effective_api_key)
        
        if use_mock or not api_key:
            add_log("📌 Running in DEMO mode (simulated evaluations)")
        else:
            add_log("🔑 Running with API authentication")
        
        add_log(f"📋 Starting optimization for prompt ({len(prompt_input)} chars)")
        add_log(f"⚙️ Settings: max_iterations={max_iterations}, target={target_score}")
        add_log("-" * 50)
        
        # Progress placeholder
        progress_placeholder = st.empty()
        
        def progress_callback(msg):
            add_log(msg)
            progress_placeholder.info(msg)
        
        try:
            results = optimizer.optimize(prompt_input, progress_callback=progress_callback)
            st.session_state.optimization_results = results
            
            add_log("-" * 50)
            add_log(f"🏁 Optimization complete!")
            add_log(f"📈 Final improvement: +{results['improvement']:.1f} points")
            
        except Exception as e:
            add_log(f"❌ Error: {str(e)}")
            st.error(f"Optimization failed: {e}")
        
        finally:
            st.session_state.is_running = False
            progress_placeholder.empty()
            st.rerun()
    
    # Results section
    st.divider()
    render_results_section()
    
    # Footer
    st.divider()
    st.markdown("""
    <div style="text-align: center; color: #888; font-size: 0.9rem;">
        Prompt Optimization System | 37 Metrics | 7 Categories | Scientific Approach
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
